import json, sys, time

## Prompts the user to add 3 items to their inventory   
def create_inventory(character):
    type_text("Please add three items to your inventory...")
    for _ in range(3):
        item_name = input("Item name: ").lower()
        while True:
            try:
                item_amount = int(input("Item Quantity: "))       
            except ValueError:
                print("Please enter a valid integer.")
            else:
                if item_amount <= 0:
                    print("Quantity must be greater than 0.")
                    continue
                break
        update_inventory(character, item_name, item_amount)

## Allows the user to update the character's inventory
def update_inventory(char, search_key, new_value):
    inv = char["inventory"]
    if search_key in inv:
        inv[search_key] += new_value
    else:
        inv[search_key] = new_value        

## Allows the user to replace the name and level of the character
def replace_field(character, search_field, new_value):
    character[search_field] = new_value

def find_item(character, search_item):
    inv = character["inventory"]
    return inv.get(search_item, 0)

## Prints summary of the character, including name, level and inventory items
def character_summary(character): 
    print()
    print("--- Character Summary ---")
    print(f"Name: {character["name"]}")
    print(f"Level: {character["level"]}")
    inventory_summary(character["inventory"])
    print()

## Used to display inventory items
def inventory_summary(inv): ## Prints a summary of all inventory items and manages popped inventory items(items with a quantity 0 or less)
    unique_count = 0
    total_item_count = 0  
    pop_items = []
    for item in inv:
        if inv[item] <= 0:
            pop_items.append(item)
    for item in pop_items:
        inv.pop(item)

    print("--- Inventory ---")
    for item in inv:
        print(f"{item.title()}: {inv[item]}")
        total_item_count += inv[item]
        if inv[item] > 0:
            unique_count += 1
    print(f"Unique Item Types in Stock: {unique_count}")
    print(f"Total individual Items: {total_item_count}")

## For flavor
def type_text(message, delay = 0.05):
    for char in message:
        print(char, end="", flush = True)
        time.sleep(delay)
    print()

# Attempts to open an existing character file
while True:
    try:
        with open("character.json", "r") as file:
            character = json.load(file)
    except FileNotFoundError:
        type_text("No character file could be loaded...") 
        type_text("Welcome to Character Creation")

        # --- Character Creation ---
        character = {
            "name": None,
            "level": None,
            "inventory": {}
        }

        character["name"] = input("Enter your character's name: ")
        while True:
            try:
                character["level"] = int(input("Enter your character's level: "))
                if character["level"] <= 0:
                    raise ValueError
            except ValueError:
                print("Please enter a valid integer greater than 0.")
            else:
                break

        #----- Inventory Creation-----
        create_inventory(character)

        ## Dumps character data into .json file
        with open("character.json", "w") as file:
            json.dump(character, file)
        break
    except json.JSONDecodeError:
        print("The file may be corrupted or invalid.")
        print("Please repair or remove the file before continuing.")
        sys.exit()
    else:
        break

#--- Character Editor---
print()
print("Welcome to the Character Editor")


while True:
    character_summary(character)
    try:
        
        print("Choose from the following fields to edit: ")
        type_text("Name")
        type_text("Level")
        type_text("Inventory")
        type_text("Quit")
        edit_category = input().lower()

        if edit_category == "quit":
            ## Print final summary, dump information to json file, then exit the program loop and end the program
            print("##--- Final Character Summary ---##")
            character_summary(character)
            with open("character.json", "w") as file:
                json.dump(character, file)
            break
        elif edit_category not in character:
            raise ValueError
    except ValueError:
        print("Edit Category could not be found.")
    else:
        
        if edit_category == "name":
            update_name = input("New Name: ")
            replace_field(character, "name", update_name)
            print()
            
        elif edit_category == "level":
            try:
                update_level = int(input("New Level: "))
                if update_level <= 0:
                    raise ValueError
            except ValueError:
                type_text("Level must be a positive integer. Please try again...")
            else:
                replace_field(character, "level", update_level)
            print()
            
        elif edit_category == "inventory":
            item_name = input("Item Name: ").lower().strip()
            items_found = find_item(character, item_name)
            if items_found > 0:
                print(f"{item_name.title()} found: {items_found}.", end=" ")
                type_text("The entry will be updated...")
            elif items_found <= 0:
                print("Item could not be found.", end = " ")
                type_text("A new item will be added...")

            while True:
                try:
                    item_quantity = int(input("Item Quantity: "))
                except ValueError:
                    type_text("The quantity must be a valid integer.")
                    print()
                else:
                    update_inventory(character, item_name, item_quantity)
                    break 